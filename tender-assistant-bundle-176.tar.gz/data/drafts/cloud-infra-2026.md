# Draft readiness memo — Fourniture de services d'infrastructure cloud hybride et support technique

- Tender ID: cloud-infra-2026
- Buyer: Canton de Vaud - Direction des systèmes d'information
- Location: Lausanne, VD
- Source: local_fallback
- Human review: APPROVED by Jean on 2026-09-20T19:11:01.628114Z
- Reviewer notes: OK for demo

## Recommendation: MAYBE — score 61.1/100 (MEDIUM confidence)

Fourniture de services d'infrastructure cloud hybride et support technique (Canton de Vaud - Direction des systèmes d'information, Lausanne, VD). Recommendation: MAYBE (score 61.1/100, confidence MEDIUM). Score is 61.1/100, but capped at MAYBE because mandatory requirement(s) remain UNKNOWN against the HPE profile (not a confirmed gap, but not confirmed met either): Le soumissionnaire doit disposer d'une certification ISO/IEC 27001 valide.; Le soumissionnaire doit justifier d'une couverture d'assurance responsabilité civile professionnelle d'au moins CHF 5'000'000.; Le soumissionnaire doit être inscrit au registre du commerce suisse ou disposer d'un établissement stable en Suisse.; ISO/IEC 27001; Au moins 2 références de projets d'infrastructure cloud ou data center réalisés en Suisse au cours des 5 dernières années.

## Submission deadline
- Submission deadline: 2026-11-02 (source: notice.txt)

## Confirmed HPE capability matches
- Le prestataire doit proposer une solution d'infrastructure hyperconvergée avec redondance géographique sur au moins 2 sites. — HPE capability: managed cloud infrastructure
- Support technique 24/7 avec un temps de réponse maximum de 4h pour les incidents critiques. — HPE capability: technical support
- Mise en place de services réseau sécurisés entre le data center et le cloud public. — HPE capability: data center services

## Confirmed gaps to close before bidding
- None confirmed.

## Open unknowns to resolve
- Le soumissionnaire doit disposer d'une certification ISO/IEC 27001 valide.
- Le soumissionnaire doit justifier d'une couverture d'assurance responsabilité civile professionnelle d'au moins CHF 5'000'000.
- Le soumissionnaire doit être inscrit au registre du commerce suisse ou disposer d'un établissement stable en Suisse.
- ISO/IEC 27001
- Au moins 2 références de projets d'infrastructure cloud ou data center réalisés en Suisse au cours des 5 dernières années.
- Au moins 2 références de projets d'infrastructure cloud ou data center réalisés en Suisse au cours des 5 dernières années.

## Next actions
- Resolve UNKNOWN items by adding sourced entries (with a citation) to data/hpe_profile.json, or by confirming directly with the relevant HPE team.
- Request more research/clarification before committing a bid team.

## Risks
- [MEDIUM] Délai de mise en oeuvre technique important (redondance géographique sur 2 sites).
- [MEDIUM] Dépendance à la disponibilité de personnel certifié cloud hybride.

## Sources / citations
- cahier_des_charges.txt (§section 4.1)
- notice.txt
