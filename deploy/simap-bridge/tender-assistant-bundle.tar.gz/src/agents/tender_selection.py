"""TenderSelectionAgent — automatic, transparent tender selection.

Scores every search-result-level `Tender` on six dimensions and ranks them,
so `WorkflowOrchestrator.run` can select the best one automatically while
keeping 2-3 runner-ups for traceability and manual override:

- cloud_infrastructure_fit / managed_services_fit / cybersecurity_fit:
  keyword overlap (title + scope) against the subset of `data/hpe_profile.json`
  capabilities whose *name* matches that theme (e.g. "hybrid cloud" for
  cloud infrastructure) — the theme keyword sets are never invented
  separately, they're read straight from the same editable profile the rest
  of the app already trusts.
- hpe_capability_fit: the same keyword overlap against the *entire*
  capability list (catches capabilities outside those three themes, e.g.
  networking or AI infrastructure).
- deadline_fit: `Tender.submission_deadline` (real field only — search
  results from SimapAdapter never carry one, see
  `src/adapters/tender_search.py`; that stays honestly neutral, never guessed).
- documents_available: whether `DocumentRetrievalTool.retrieve_documents`
  actually succeeds for this tender — a real check, not an assumption.

No LLM call — deterministic, and reuses `src.agents.matching.significant_tokens`
(the same tokenizer `eligibility_gate.py`/`fit_scoring.py` already use), so
this is one more consumer of that shared primitive, not a second scoring
implementation. `fit_scoring.py`'s HPE *qualification* score is untouched —
this module answers a different question (which candidate to analyze first),
computed on search-result metadata alone, before any document is extracted.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime

from pydantic import BaseModel, Field

from src.adapters import AdapterUnavailableError
from src.agents.matching import significant_tokens
from src.agents.retrieval import DocumentRetrievalTool
from src.schemas.briefing import AlternativeTender
from src.schemas.hpe_profile import Capability, HPEProfile
from src.schemas.tender import Tender, TenderDocument

_MAX_CLOUD = 20.0
_MAX_MANAGED = 20.0
_MAX_CYBER = 20.0
_MAX_CAPABILITY = 20.0
_MAX_DEADLINE = 10.0
_MAX_DOCUMENTS = 10.0
# 20 + 20 + 20 + 20 + 10 + 10 = 100, mirroring ScoreBreakdown's style.

# A ratio of significant-keyword overlap >= this is a "MATCH" in
# src.agents.matching._capability_overlap — reused here as the point where a
# themed/overall capability-fit dimension hits its own max points, instead of
# inventing a separate cutoff.
_FULL_SCORE_RATIO = 0.25

_CLOUD_NAME_HINTS = ("cloud", "data center")
_MANAGED_NAME_HINTS = ("managed", "support", "consulting")
_CYBER_NAME_HINTS = ("cyber", "security")


class RelevanceScoreBreakdown(BaseModel):
    """Transparent point allocation for automatic tender selection. Max points: 20/20/20/20/10/10 = 100."""

    cloud_infrastructure_fit: float = Field(..., ge=0, le=_MAX_CLOUD)
    managed_services_fit: float = Field(..., ge=0, le=_MAX_MANAGED)
    cybersecurity_fit: float = Field(..., ge=0, le=_MAX_CYBER)
    hpe_capability_fit: float = Field(..., ge=0, le=_MAX_CAPABILITY)
    deadline_fit: float = Field(..., ge=0, le=_MAX_DEADLINE)
    documents_available: float = Field(..., ge=0, le=_MAX_DOCUMENTS)
    notes: list[str] = Field(default_factory=list, description="One short explanation per dimension, in the same order.")

    @property
    def total(self) -> float:
        return (
            self.cloud_infrastructure_fit
            + self.managed_services_fit
            + self.cybersecurity_fit
            + self.hpe_capability_fit
            + self.deadline_fit
            + self.documents_available
        )


@dataclass
class TenderRelevance:
    """One scored candidate — carries its already-fetched documents so a
    later extraction step (for whichever candidate ends up selected) never
    re-fetches them."""

    tender: Tender
    breakdown: RelevanceScoreBreakdown
    documents: list[TenderDocument]

    @property
    def total(self) -> float:
        return self.breakdown.total


def _capabilities_by_name_hint(profile: HPEProfile, hints: tuple[str, ...]) -> list[Capability]:
    return [c for c in profile.capabilities if any(hint in c.name.lower() for hint in hints)]


def _capability_fit_score(text: str, capabilities: list[Capability], max_points: float, theme: str) -> tuple[float, str]:
    if not capabilities:
        return round(max_points * 0.5, 1), f"{theme}: no matching HPE capability listed in the profile (neutral)"

    text_tokens = significant_tokens(text)
    if not text_tokens:
        return 0.0, f"{theme}: tender title/scope has no significant keywords to match on"

    cap_tokens = significant_tokens(" ".join(f"{c.name} {c.description or ''}" for c in capabilities))
    overlap = text_tokens & cap_tokens
    ratio = len(overlap) / len(text_tokens)
    score = round(min(ratio / _FULL_SCORE_RATIO, 1.0) * max_points, 1)
    names = "/".join(c.name for c in capabilities)
    return score, f"{theme}: {ratio:.0%} keyword overlap with HPE capabilities ({names})"


def _deadline_score(tender: Tender, as_of: date, max_points: float) -> tuple[float, str]:
    if tender.submission_deadline is None:
        return round(max_points * 0.5, 1), "Deadline: UNKNOWN (not provided by this search result) — neutral"

    days_left = (tender.submission_deadline - as_of).days
    if days_left < 0:
        return 0.0, f"Deadline: already passed ({-days_left} day(s) ago)"
    if days_left < 7:
        return round(max_points * 0.3, 1), f"Deadline: in {days_left} day(s) — very tight"
    if days_left < 14:
        return round(max_points * 0.6, 1), f"Deadline: in {days_left} day(s) — tight but workable"
    return max_points, f"Deadline: in {days_left} day(s) — comfortable lead time"


def _documents_score(
    tender: Tender, retrieval_tool: DocumentRetrievalTool, max_points: float
) -> tuple[float, list[TenderDocument], str]:
    try:
        documents = retrieval_tool.retrieve_documents(tender)
    except AdapterUnavailableError as exc:
        return 0.0, [], f"Documents: not retrievable ({exc})"
    if not documents:
        return 0.0, [], "Documents: none found for this tender"
    return max_points, documents, f"Documents: {len(documents)} available"


def score_tender(
    tender: Tender, profile: HPEProfile, retrieval_tool: DocumentRetrievalTool, as_of: date
) -> TenderRelevance:
    """Score one candidate. Document retrieval happens here (not just at
    extraction time) because "documents present" is itself one of the
    scoring dimensions — the fetched documents are kept on the result so the
    eventual winner's extraction step reuses them instead of re-fetching."""
    text = f"{tender.title} {tender.scope or ''}".strip()

    cloud_score, cloud_note = _capability_fit_score(
        text, _capabilities_by_name_hint(profile, _CLOUD_NAME_HINTS), _MAX_CLOUD, "Cloud infrastructure"
    )
    managed_score, managed_note = _capability_fit_score(
        text, _capabilities_by_name_hint(profile, _MANAGED_NAME_HINTS), _MAX_MANAGED, "Managed services"
    )
    cyber_score, cyber_note = _capability_fit_score(
        text, _capabilities_by_name_hint(profile, _CYBER_NAME_HINTS), _MAX_CYBER, "Cybersecurity"
    )
    capability_score, capability_note = _capability_fit_score(
        text, profile.capabilities, _MAX_CAPABILITY, "HPE capability match (overall)"
    )
    deadline_score, deadline_note = _deadline_score(tender, as_of, _MAX_DEADLINE)
    documents_score, documents, documents_note = _documents_score(tender, retrieval_tool, _MAX_DOCUMENTS)

    notes = [cloud_note, managed_note, cyber_note, capability_note, deadline_note, documents_note]
    breakdown = RelevanceScoreBreakdown(
        cloud_infrastructure_fit=cloud_score,
        managed_services_fit=managed_score,
        cybersecurity_fit=cyber_score,
        hpe_capability_fit=capability_score,
        deadline_fit=deadline_score,
        documents_available=documents_score,
        # Each note is a full clause without trailing punctuation — add a
        # period here, once, so joining them for selection_reason reads as
        # separate sentences instead of running on.
        notes=[n if n.endswith(".") else f"{n}." for n in notes],
    )
    return TenderRelevance(tender=tender, breakdown=breakdown, documents=documents)


def rank_candidates(
    candidates: list[Tender],
    profile: HPEProfile,
    retrieval_tool: DocumentRetrievalTool,
    as_of: date | None = None,
) -> list[TenderRelevance]:
    """Score every candidate and return them best-first."""
    resolved_as_of = as_of or datetime.now(UTC).date()
    scored = [score_tender(t, profile, retrieval_tool, resolved_as_of) for t in candidates]
    scored.sort(key=lambda r: r.total, reverse=True)
    return scored


def build_alternatives(ranked: list[TenderRelevance], exclude_id: str, limit: int = 3) -> list[AlternativeTender]:
    """2-3 runner-ups (whatever is left after excluding the selected id), best-first."""
    runner_ups = [r for r in ranked if r.tender.id != exclude_id]
    return [
        AlternativeTender(tender_id=r.tender.id, title=r.tender.title, relevance_score=round(r.total, 1), rank=i + 1)
        for i, r in enumerate(runner_ups[:limit])
    ]


def auto_selection_reason(selected: TenderRelevance, runner_ups: list[TenderRelevance]) -> str:
    headline = (
        f"Automatically selected '{selected.tender.title}' (id={selected.tender.id}) as the "
        f"highest-relevance candidate ({selected.total:.1f}/100)."
    )
    parts = [headline]
    parts.extend(selected.breakdown.notes)
    if runner_ups:
        runner_up_desc = "; ".join(f"{r.tender.id} ({r.total:.1f}/100)" for r in runner_ups[:3])
        parts.append(f"Runner-up candidate(s): {runner_up_desc}.")
    return " ".join(parts)


def override_selection_reason(selected: TenderRelevance, auto_pick: TenderRelevance) -> str:
    if selected.tender.id == auto_pick.tender.id:
        # A human "override" that happens to match the automatic pick — still
        # record it as an override (that's what was asked for), but say so honestly.
        return (
            f"Manually selected '{selected.tender.title}' (id={selected.tender.id}) via human override — "
            f"this happens to match the automatic pick ({selected.total:.1f}/100)."
        )
    return (
        f"Manually selected '{selected.tender.title}' (id={selected.tender.id}, relevance score "
        f"{selected.total:.1f}/100) via human override, overriding the automatic pick "
        f"'{auto_pick.tender.title}' (id={auto_pick.tender.id}, relevance score {auto_pick.total:.1f}/100)."
    )
