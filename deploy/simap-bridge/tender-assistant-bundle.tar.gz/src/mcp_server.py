"""MCP stdio server exposing the HPE tender qualification workflow.

Lets Hermes/NemoClaw drive the real pipeline (src/agents/*, src/adapters/*)
as MCP tools instead of a human running `python -m src.pipeline` by hand.
This module is a thin adapter layer only: every tool below calls straight
into the existing, already-tested agents/adapters. No search, extraction,
matching, scoring, or briefing logic is duplicated or reimplemented here —
see docs/architecture.md and IMPLEMENTATION_LOG.md for why those are
deterministic/local-fallback-first in this environment.

Run it directly:

    python -m src.mcp_server

Register with Hermes as a native stdio MCP server (same pattern as the
SIMAP MCP server documented in integrations/simap/README.md, but a local
Python command instead of a Node one — see `hermes mcp add --help`):

    mcp_servers:
      hpe-tender-qualification:
        command: python3
        args: ["-m", "src.mcp_server"]
        cwd: /path/to/this/repo   # so `src` and `data/` resolve
        connect_timeout: 10

See IMPLEMENTATION_LOG.md for the full launch/registration notes.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from src.adapters import AdapterUnavailableError
from src.agents import matching
from src.agents.ingestion import extract_requirements as run_extraction
from src.agents.workflow import WorkflowOrchestrator
from src.schemas.tender import Tender

REPO_ROOT = Path(__file__).resolve().parents[1]
BRIEFINGS_DIR = REPO_ROOT / "data" / "briefings"

mcp = FastMCP(
    "hpe-tender-qualification",
    instructions=(
        "Tools for qualifying Swiss public tenders against the HPE capability "
        "profile: search_tenders -> get_tender -> extract_requirements -> "
        "match_hpe_capabilities -> qualify_tender -> create_briefing. Every "
        "tool returns structured JSON with 'sources'/'citations'/'unknowns' "
        "fields; unresolved facts are reported as UNKNOWN rather than guessed. "
        "Local sample data (data/sample_tenders.json, data/hpe_profile.json) "
        "is clearly labeled 'local_sample' and is never presented as live "
        "SIMAP data."
    ),
)

_orchestrator: WorkflowOrchestrator | None = None


def _get_orchestrator() -> WorkflowOrchestrator:
    """Lazily build the single WorkflowOrchestrator this server reuses.

    Read-only after construction (search/retrieval adapters + the loaded HPE
    profile), so one shared instance across calls is safe.
    """
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = WorkflowOrchestrator()
    return _orchestrator


def _find_tender(orchestrator: WorkflowOrchestrator, tender_id: str) -> Tender | None:
    return next((t for t in orchestrator.search("") if t.id == tender_id), None)


_PROVENANCE_NOTES = {
    "local_sample": (
        "Sourced from local sample fixtures under data/ "
        "(data/sample_tenders.json, data/sample_tenders/) — NOT a live SIMAP connection."
    ),
    "simap": "Sourced from a live SIMAP connection.",
    "tavily": "Sourced from a live Tavily search.",
}


def _provenance_note(source: str) -> str:
    return _PROVENANCE_NOTES.get(source, f"Unrecognized source '{source}' — provenance UNKNOWN.")


def _tender_citation(tender: Tender) -> dict[str, Any]:
    """A traceability record for a Tender search-result — same shape as schemas.common.Citation."""
    document = "data/sample_tenders.json" if tender.source.value == "local_sample" else (tender.url or "search index")
    return {"document": document, "page": None, "section": None, "quote": None}


def _dump(model: Any) -> Any:
    """model_dump via JSON round-trip, so date/datetime/enum values serialize cleanly."""
    return json.loads(model.model_dump_json())


def _ok(tool: str, **fields: Any) -> dict[str, Any]:
    return {"tool": tool, "status": "ok", **fields}


def _error(tool: str, message: str, **fields: Any) -> dict[str, Any]:
    return {
        "tool": tool,
        "status": "error",
        "message": message,
        "sources": [],
        "citations": [],
        "unknowns": [message],
        **fields,
    }


@mcp.tool()
def search_tenders(query: str) -> dict[str, Any]:
    """Search Swiss public tenders relevant to HPE's qualification workflow.

    Reuses TenderSearchTool (src/agents/search.py over src/adapters/tender_search.py),
    which prefers SIMAP/Tavily when reachable and otherwise falls back to the local
    sample index at data/sample_tenders.json. Each result's true `source` field
    ("simap" | "tavily" | "local_sample") is preserved — local sample results are
    never presented as if they came from a live SIMAP connection.
    """
    orchestrator = _get_orchestrator()
    try:
        tenders = orchestrator.search(query)
    except AdapterUnavailableError as exc:
        return _error("search_tenders", str(exc), query=query)

    sources = sorted({t.source.value for t in tenders})
    return _ok(
        "search_tenders",
        query=query,
        count=len(tenders),
        tenders=[_dump(t) for t in tenders],
        sources=sources,
        citations=[_tender_citation(t) for t in tenders],
        notes=[_provenance_note(s) for s in sources] or ["No tenders matched this query."],
        unknowns=[],
    )


@mcp.tool()
def get_tender(tender_id: str) -> dict[str, Any]:
    """Look up a single tender by id from the current search index.

    tender_id must match a `Tender.id` previously returned by search_tenders
    (e.g. "cloud-infra-2026"). Returns status="error" with the tender field
    set to null (UNKNOWN) if no tender with that id exists.
    """
    orchestrator = _get_orchestrator()
    tender = _find_tender(orchestrator, tender_id)
    if tender is None:
        return _error("get_tender", f"Unknown tender id: {tender_id!r}", tender_id=tender_id, tender=None)

    return _ok(
        "get_tender",
        tender_id=tender_id,
        tender=_dump(tender),
        sources=[tender.source.value],
        citations=[_tender_citation(tender)],
        notes=[_provenance_note(tender.source.value)],
        unknowns=[],
    )


@mcp.tool()
def extract_requirements(tender_id: str) -> dict[str, Any]:
    """Retrieve a tender's documents and extract structured, cited requirements.

    Reuses DocumentRetrievalTool (src/agents/retrieval.py) and
    src.agents.ingestion.extract_requirements unmodified. Every requirement
    carries a `citation` back to its source document/section when known;
    facts that could not be determined are listed in `unknowns` rather than
    inferred.
    """
    orchestrator = _get_orchestrator()
    tender = _find_tender(orchestrator, tender_id)
    if tender is None:
        return _error("extract_requirements", f"Unknown tender id: {tender_id!r}", tender_id=tender_id)

    try:
        documents = orchestrator.retrieval_tool.retrieve_documents(tender)
    except AdapterUnavailableError as exc:
        return _error("extract_requirements", str(exc), tender_id=tender_id)

    extracted = run_extraction(tender, documents)
    payload = _dump(extracted)
    return _ok(
        "extract_requirements",
        tender_id=tender_id,
        extracted_requirements=payload,
        sources=extracted.source_documents,
        citations=payload["citations"],
        notes=[_provenance_note(tender.source.value)],
        unknowns=extracted.unknowns,
    )


@mcp.tool()
def match_hpe_capabilities(tender_id: str) -> dict[str, Any]:
    """Match a tender's extracted requirements against the HPE capability profile.

    Reuses src/agents/matching.py `match_all` unmodified — deterministic
    keyword-overlap matching, no scoring/matching logic duplicated here.
    Every match is MATCH / PARTIAL_MATCH / NO_MATCH / UNKNOWN with a
    justification and, when available, a citation. UNKNOWN is used whenever
    the HPE profile (data/hpe_profile.json) has no sourced entry to confirm
    or deny a requirement — it is never guessed as a match.
    """
    orchestrator = _get_orchestrator()
    tender = _find_tender(orchestrator, tender_id)
    if tender is None:
        return _error("match_hpe_capabilities", f"Unknown tender id: {tender_id!r}", tender_id=tender_id)

    try:
        documents = orchestrator.retrieval_tool.retrieve_documents(tender)
    except AdapterUnavailableError as exc:
        return _error("match_hpe_capabilities", str(exc), tender_id=tender_id)

    extracted = run_extraction(tender, documents)
    matches = matching.match_all(extracted.all_requirements(), orchestrator.hpe_profile)
    payload = [_dump(m) for m in matches]
    unknown_descriptions = [m["requirement_description"] for m in payload if m["status"] == "unknown"]
    citations = [m["citation"] for m in payload if m["citation"] is not None]

    return _ok(
        "match_hpe_capabilities",
        tender_id=tender_id,
        matches=payload,
        sources=[*extracted.source_documents, "data/hpe_profile.json"],
        citations=citations,
        notes=[_provenance_note(tender.source.value)],
        unknowns=[*unknown_descriptions, *extracted.unknowns],
    )


def _run_qualification(orchestrator: WorkflowOrchestrator, tender: Tender):
    """retrieve -> extract -> qualify, via WorkflowOrchestrator.analyze_tender (unmodified)."""
    return orchestrator.analyze_tender(tender)


@mcp.tool()
def qualify_tender(tender_id: str) -> dict[str, Any]:
    """Run the full eligibility-gate + fit-scoring qualification for a tender.

    Reuses src/agents/qualification.py `qualify_tender` (itself composing
    eligibility_gate + fit_scoring + briefing, all unmodified) via
    WorkflowOrchestrator.analyze_tender — no scoring rule is reimplemented
    here. Returns the resulting GO / MAYBE / NO-GO recommendation, score
    breakdown, gaps, risks, and unknowns.
    """
    orchestrator = _get_orchestrator()
    tender = _find_tender(orchestrator, tender_id)
    if tender is None:
        return _error("qualify_tender", f"Unknown tender id: {tender_id!r}", tender_id=tender_id)

    try:
        briefing_result = _run_qualification(orchestrator, tender)
    except AdapterUnavailableError as exc:
        return _error("qualify_tender", str(exc), tender_id=tender_id)

    payload = _dump(briefing_result)
    sources = sorted({c["document"] for c in payload["citations"]} | {"data/hpe_profile.json"})
    return _ok(
        "qualify_tender",
        tender_id=tender_id,
        briefing=payload,
        sources=sources,
        citations=payload["citations"],
        notes=[_provenance_note(tender.source.value)],
        unknowns=payload["unknowns"],
    )


@mcp.tool()
def create_briefing(tender_id: str) -> dict[str, Any]:
    """Produce and persist the final structured qualification briefing for a tender.

    Runs the same pipeline as qualify_tender (search -> retrieve -> extract ->
    qualify, all unmodified) and additionally writes the briefing JSON to
    data/briefings/<tender_id>.json — mirroring
    `python -m src.pipeline analyze <id> --out ...` — so Hermes/NemoClaw gets
    back a durable, re-readable artifact rather than only an in-memory result.
    """
    orchestrator = _get_orchestrator()
    tender = _find_tender(orchestrator, tender_id)
    if tender is None:
        return _error("create_briefing", f"Unknown tender id: {tender_id!r}", tender_id=tender_id)

    try:
        briefing_result = _run_qualification(orchestrator, tender)
    except AdapterUnavailableError as exc:
        return _error("create_briefing", str(exc), tender_id=tender_id)

    payload = _dump(briefing_result)
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = BRIEFINGS_DIR / f"{tender_id}.json"
    out_path.write_text(briefing_result.model_dump_json(indent=2), encoding="utf-8")

    sources = sorted({c["document"] for c in payload["citations"]} | {"data/hpe_profile.json"})
    return _ok(
        "create_briefing",
        tender_id=tender_id,
        briefing=payload,
        saved_to=str(out_path.relative_to(REPO_ROOT)) if out_path.is_relative_to(REPO_ROOT) else str(out_path),
        sources=sources,
        citations=payload["citations"],
        notes=[_provenance_note(tender.source.value)],
        unknowns=payload["unknowns"],
    )


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
